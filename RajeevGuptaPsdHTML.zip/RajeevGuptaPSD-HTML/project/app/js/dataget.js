  $(document).ready(function() {
   $.getJSON('products.json', function(data) {
	   
	   
       $.each(data, function(i, f) {
		   var btnsal="";
		   var btnexc="";
		   if(f.isSale==true) {
			   btnsal="&nbsp;<button class='btnsale'>Sale</button>" 
			   } 
		   else if(f.isExclusive==true){
			   btnexc="&nbsp;<button class='btnexcl'>Exclusive</button>"
		   }
		 else {btnsal="<br><br><div style='height:9px'></div>"}
          var colm = "<div class='col-3 col-m-6 border'><img src='Products/" + f.productImage + "'>" + btnsal
		    + btnexc + "<br><br><div class='row'><div class='col-9'>" + f.productName + "</div><div class='col-3' align='right'>" + f.price + "</div></div>&nbsp;Size: " + f.size +  "</div>"
		   	   
			
			   $(colm).appendTo("#ro");			   
           
     });

	 
$('#sizesel').change(function() {
$("div.col-3").remove();
var valu = $(this).val();

	$.each(data, function(i, f) {
		
	if ($.inArray(valu, f.size) != '-1') {

	var btnsal="";
		   var btnexc="";
		   if(f.isSale==true) {
			   btnsal="&nbsp;<button class='btnsale'>Sale</button>" 
			   } 
		   else if(f.isExclusive==true){
			   btnexc="&nbsp;<button class='btnexcl'>Exclusive</button>"
		   }
		 else {btnsal="<br><br><div style='height:9px'></div>"}
          var colm = "<div class='col-3 col-m-6 border'><img src='Products/" + f.productImage + "'>" + btnsal
		    + btnexc + "<br><br><div class='row'><div class='col-9'>" + f.productName + "</div><div class='col-3' align='right'>" + f.price + "</div></div>&nbsp;Size: " + f.size +  "</div>"
		   	   
			
			   $(colm).appendTo("#ro");
	}
	
	else if (valu=="") {
		
		var btnsal="";
		   var btnexc="";
		   if(f.isSale==true) {
			   btnsal="&nbsp;<button class='btnsale'>Sale</button>" 
			   } 
		   else if(f.isExclusive==true){
			   btnexc="&nbsp;<button class='btnexcl'>Exclusive</button>"
		   }
		 else {btnsal="<br><br><div style='height:9px'></div>"}
          var colm = "<div class='col-3 col-m-6 border'><img src='Products/" + f.productImage + "'>" + btnsal
		    + btnexc + "<br><br><div class='row'><div class='col-9'>" + f.productName + "</div><div class='col-3' align='right'>" + f.price + "</div></div>&nbsp;Size: " + f.size +  "</div>"
		   	   
			
			   $(colm).appendTo("#ro");
		
	}
	     });
});
 
	 
	 
   });

});

