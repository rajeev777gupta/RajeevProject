Rajeev Gupta project PSD to HTML with scss, Gulp, Node JS, JSON, JQuery


Procedure to run the application directly:

1. The application can be run directly by opening folder 'app', then double clicking the index.html file. It will load the data from products.json file and images from the Products folder.


Procedure to build and run the application through Node Package Manager :

1. Install Node.js after downloading it from its website.
2. Install gulp globally in command prompt window by typing npm install gulp -g.
3. Change directory to project folder. Then type npm init. Then type npm install gulp --save-dev

4. Type gulp watch comand, then it will compile the scss file, build the project and the index.html will automatically open in a browser window with url as localhost:3000
Also If we make any changes in scss file, js file or html file, it will automatically compile scss into css file, build the web application and reload the browser window at run time.

5. The Filter by size is enabled. If you select any size, the items of that size will only be visible.

https://github.com/rajeev777gupta/RajeevProject