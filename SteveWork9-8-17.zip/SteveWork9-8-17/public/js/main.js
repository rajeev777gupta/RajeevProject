// load scripts

var cachebuster = Math.floor((Math.random() * 100000000) + 1);

head.load(

    // load all dependencies
    "public/js/pages/global.js?"+cachebuster+"",

    function() {
        // load page specific scripts
        var index = document.getElementById("index");
        var post = document.getElementById("post");
        var list = document.getElementById("list");
        var general = document.getElementById("general");
        var partners = document.getElementById("partners");
        var contact = document.getElementById("contact");

        if ( index ) {
            head.load("https://s3-us-west-2.amazonaws.com/cmxcache/cmx/public/js/vendors/jquery.viewportchecker.js?"+cachebuster);
            head.load("public/js/pages/index.js?"+cachebuster);
        }
        if ( post ) {
            head.load("https://s3-us-west-2.amazonaws.com/cmxcache/cmx/public/js/vendors/jquery.viewportchecker.js?"+cachebuster);
            head.load("public/js/pages/post.js?"+cachebuster);
        }
        if ( list ) {
            head.load("https://s3-us-west-2.amazonaws.com/cmxcache/cmx/public/js/vendors/jquery.viewportchecker.js?"+cachebuster);
            head.load("public/js/pages/list.js?"+cachebuster);
        }
    }
);

$(document).ready(function() {
   

	
});